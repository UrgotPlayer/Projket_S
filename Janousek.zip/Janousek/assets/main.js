// Initialize Nette Forms on page load
import netteForms from 'nette-forms';

netteForms.initOnLoad();
