CREATE TABLE `uzivatele` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `uzivatelske_jmeno` VARCHAR(80) NOT NULL,
    `jmeno` VARCHAR(80) NOT NULL,
    `prijmeni` VARCHAR(80) NOT NULL,
    `heslo` VARCHAR(255) NOT NULL,
    `email` VARCHAR(180) NOT NULL,
    `adresa_ulice` VARCHAR(160) NOT NULL,
    `adresa_psc` CHAR(5) NOT NULL,
    `adresa_obec` VARCHAR(120) NOT NULL,
    `koren_ulice` VARCHAR(160) NOT NULL,
    `koren_psc` CHAR(5) NOT NULL,
    `koren_obec` VARCHAR(120) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_uzivatel_username` (`uzivatelske_jmeno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;
