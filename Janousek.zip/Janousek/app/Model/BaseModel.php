<?php

namespace App\Model;

use Nette\Database\Connection;
use Nette\Database\Explorer;

abstract class BaseModel
{
    /** @var Explorer */
    protected $explorer;

    /** @var Connection */
    protected $connection;

    function __construct(Explorer $explorer)
    {
        // Inicializace
        $this->explorer = $explorer;
        $this->connection = $explorer->getConnection();
    }

    abstract protected function getTableName(): string;

    public function getAllRecords()
    {
        return $this->explorer->table($this->getTableName());
    }

    public function insert($data)
    {
        // Vlozeni zaznamu do databaze
        return $this->getAllRecords()->insert($data);
    }
}