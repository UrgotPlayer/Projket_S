<?php

declare(strict_types=1);

namespace App\Model\Uzivatel\ValueObject;

final class Address
{
    public function __construct(
        public readonly string $street,
        public readonly string $zip,
        public readonly string $city,
    ) {
    }

    public function toArray(string $prefix): array
    {
        return [
            $prefix . '_ulice' => $this->street,
            $prefix . '_psc' => $this->zip,
            $prefix . '_obec' => $this->city,
        ];
    }
}
