<?php

declare(strict_types=1);

namespace App\Model\Uzivatel\ValueObject;

final class UserData
{
    public function __construct(
        public readonly string $username,
        public readonly string $firstName,
        public readonly string $lastName,
        public readonly string $passwordHash,
        public readonly string $email,
        public readonly Address $permanentAddress,
        public readonly Address $correspondenceAddress,
    ) {
    }

    public function toArray(): array
    {
        return [
            'uzivatelske_jmeno' => $this->username,
            'jmeno' => $this->firstName,
            'prijmeni' => $this->lastName,
            'heslo' => $this->passwordHash,
            'email' => $this->email,
            ...$this->permanentAddress->toArray('adresa'),
            ...$this->correspondenceAddress->toArray('koren'),
        ];
    }
}
