<?php

namespace App\Model\Uzivatel;

use App\Model\BaseModel;
use App\Model\Uzivatel\ValueObject\UserData;

class UzivatelModel extends BaseModel
{
    protected function getTableName(): string
    {
        return 'uzivatele';
    }

    public function insertUser(UserData $user): void
    {
        $this->insert($user->toArray());
    }
}
