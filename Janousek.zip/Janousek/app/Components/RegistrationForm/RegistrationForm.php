<?php

declare(strict_types=1);

namespace App\Components\RegistrationForm;

use App\Components\LatteKomponenta;
use App\Model\Uzivatel\UzivatelModel;
use App\Model\Uzivatel\ValueObject\Address;
use App\Model\Uzivatel\ValueObject\UserData;
use Latte\Engine;
use Nette\Application\UI\Form;
use Nette\Database\UniqueConstraintViolationException;
use Nette\Forms\Controls;
use Nette\Forms\Controls\TextInput;
use Nette\Mail\Mailer;
use Nette\Mail\Message;
use Nette\Security\Passwords;
use Nette\Utils\ArrayHash;
use Tracy\Debugger;

class RegistrationForm extends LatteKomponenta
{
    private const NAME_FIELDS = [
        'username' => ['label' => 'Uživatelské jméno', 'maxLength' => 80],
        'first_name' => ['label' => 'Jméno', 'maxLength' => 80],
        'last_name' => ['label' => 'Příjmení', 'maxLength' => 80],
    ];

    private const ADDRESS_FIELDS = [
        'street' => ['label' => 'Ulice a číslo', 'maxLength' => 160],
        'city' => ['label' => 'Obec nebo městská část', 'maxLength' => 120],
        'corr_street' => ['label' => 'Korespondenční ulice', 'maxLength' => 160],
        'corr_city' => ['label' => 'Korespondenční obec', 'maxLength' => 120],
    ];

    public function __construct(
        private readonly UzivatelModel $uzivatelModel,
        private readonly Passwords $passwords,
        private readonly Mailer $mailer,
        private readonly Engine $latte,
    ) {
    }

    protected function getTemplateFileName(): string
    {
        return __DIR__ . '/RegistrationForm.latte';
    }

    protected function createComponentRegistracniFormular(): Form
    {
        $form = new Form();

        $this->buildIdentitySection($form);
        $this->buildAddressSection($form);

        $form->addProtection('Platnost formuláře vypršela, odešlete jej prosím znovu.');

        $form->addSubmit('submit', 'Vytvořit účet')
            ->setHtmlAttribute('class', 'btn btn-primary w-100');

        $form->onSuccess[] = [$this, 'processRegistration'];

        $this->applyBootstrapStyling($form);

        return $form;
    }

    public function processRegistration(Form $form, ArrayHash $values): void
    {
        $user = $this->mapValuesToUser($values);

        if (!$this->persistUser($form, $user)) {
            return;
        }

        $this->notifyUser($user);
        $form->setValues([], true);
    }

    private function buildIdentitySection(Form $form): void
    {
        foreach (self::NAME_FIELDS as $name => $config) {
            $this->addRequiredText($form, $name, $config['label'], $config['maxLength']);
        }

        $form->addEmail('email', 'E-mail')
            ->setRequired('E-mail je povinný.')
            ->addRule(Form::MAX_LENGTH, 'E-mail může mít nejvýše %d znaků.', 180);

        $this->addPasswordPair($form);
    }

    private function buildAddressSection(Form $form): void
    {
        $zipFields = [
            'zip' => 'PSČ',
            'corr_zip' => 'Koresp. PSČ',
        ];

        foreach (self::ADDRESS_FIELDS as $name => $config) {
            $this->addRequiredText($form, $name, $config['label'], $config['maxLength']);
        }

        foreach ($zipFields as $name => $label) {
            $form->addText($name, $label)
                ->setRequired(sprintf('%s je povinné.', $label))
                ->addRule([$this, 'validateZip'], sprintf('%s musí mít přesně 5 číslic.', $label));
        }
    }

    private function addPasswordPair(Form $form): void
    {
        $password = $form->addPassword('password', 'Heslo')
            ->setRequired('Heslo je povinné.')
            ->addRule(Form::MIN_LENGTH, 'Heslo musí mít alespoň %d znaků.', 8);

        $form->addPassword('password_confirm', 'Potvrzení hesla')
            ->setRequired('Zadejte heslo ještě jednou.')
            ->addRule(Form::MIN_LENGTH, 'Heslo musí mít alespoň %d znaků.', 8)
            ->addRule(Form::EQUAL, 'Hesla se musí shodovat.', $password);
    }

    private function addRequiredText(Form $form, string $name, string $label, int $maxLength): TextInput
    {
        return $form->addText($name, $label)
            ->setRequired(sprintf('%s je povinné.', $label))
            ->addRule(Form::MAX_LENGTH, sprintf('%s může mít nejvýše %d znaků.', $label, $maxLength), $maxLength);
    }

    private function persistUser(Form $form, UserData $user): bool
    {
        try {
            $this->uzivatelModel->insertUser($user);
            return true;
        } catch (UniqueConstraintViolationException) {
            $form->addError('Uživatelské jméno už někdo používá. Zvolte prosím jiné.');
        } catch (\Throwable) {
            $form->addError('Registraci se nepodařilo uložit. Zkuste to prosím znovu.');
        }

        return false;
    }

    private function notifyUser(UserData $user): void
    {
        try {
            $this->sendConfirmationEmail($user);
            $this->presenter->flashMessage('Registrace byla uložena. Do e-mailu jsme poslali souhrn.', 'success');
        } catch (\Throwable) {
            $this->presenter->flashMessage('Registrace je uložená, ale e-mail se nepodařilo odeslat.', 'warning');
        }
    }

    private function mapValuesToUser(ArrayHash $values): UserData
    {
        $zip = fn(string $value): string => $this->normalizeZip($value);
        $normalize = fn(string $value): string => $this->normalizeText($value);

        $permanentAddress = new Address(
            $normalize((string) $values->street),
            $zip($values->zip),
            $normalize((string) $values->city),
        );

        $correspondenceAddress = new Address(
            $normalize((string) $values->corr_street),
            $zip($values->corr_zip),
            $normalize((string) $values->corr_city),
        );

        return new UserData(
            $normalize((string) $values->username),
            $normalize((string) $values->first_name),
            $normalize((string) $values->last_name),
            $this->passwords->hash((string) $values->password),
            $normalize((string) $values->email),
            $permanentAddress,
            $correspondenceAddress
        );
    }

    private function sendConfirmationEmail(UserData $user): string
    {
        $templatePath = __DIR__ . '/RegistrationForm.email.latte';
        $body = $this->latte->renderToString($templatePath, ['user' => $user]);
        Debugger::barDump($body, 'Email preview');

        $message = (new Message())
            ->setFrom('registrace@example.test')
            ->addTo($user->email)
            ->setSubject('Potvrzení registrace')
            ->setBody($body);

        $this->mailer->send($message);
        return $body;
    }

    private function applyBootstrapStyling(Form $form): void
    {
        $form->getElementPrototype()->addClass('needs-validation');

        foreach ($form->getControls() as $control) {
            if ($control instanceof Controls\Button) {
                $control->getControlPrototype()->addClass('btn btn-primary w-100');
            } elseif ($control instanceof Controls\Checkbox) {
                $control->getControlPrototype()->addClass('form-check-input');
                $control->getLabelPrototype()->addClass('form-check-label');
                $control->getSeparatorPrototype()->setName('div')->addClass('form-check mb-2');
            } else {
                $control->getControlPrototype()->addClass('form-control');
                $control->getLabelPrototype()->addClass('form-label fw-semibold');
            }
        }
    }

    public function validateZip(TextInput $input): bool
    {
        $normalized = $this->normalizeZip((string) $input->getValue());
        $input->setValue($normalized);

        return (bool) preg_match('/^[0-9]{5}$/', $normalized);
    }

    private function normalizeZip(string $value): string
    {
        return (string) preg_replace('/\s+/', '', trim($value));
    }

    private function normalizeText(string $value): string
    {
        return (string) preg_replace('/\s+/', ' ', trim($value));
    }
}
