<?php

declare(strict_types=1);

namespace App\Components\RegistrationForm;

interface RegistrationFormFactory
{
    public function create(): RegistrationForm;
}
