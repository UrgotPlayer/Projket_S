<?php

namespace App\Components;

use Tracy\Debugger;

class LatteKomponenta extends \Nette\Application\UI\Control
{
    /**
     * "Rozpojitelna" metoda pro jmeno souboru se sablonou
     */
    protected function getTemplateFileName() : string
    {
        // Vraceni jmena souboru pro sablonu => lze prekryt a vracet __FILE__ !!!
        return str_replace('.php', '.latte', $this->getReflection()->getFileName());
    }

    /**
     * "Virtualni" metoda pro prevzeti parametru
     *
     * @param ...$parameters
     */
    protected function putParametersIntoTemplate(...$parameters)
    {
    }

    function beforeRender(...$parameters)
    {
        // Nastaveni sablony
        $this->template->setFile($this->getTemplateFileName());

        // Predani dat do sablony
        $this->putParametersIntoTemplate(...$parameters);
    }

    function render(...$parameters)
    {
        // Nastaveni, ...
        $this->beforeRender(...$parameters);

        // Vykresleni
        $this->template->render();
    }
}