<?php

declare(strict_types=1);

namespace App\Presentation\Home;

use App\Components\RegistrationForm\RegistrationFormFactory;
use Nette;
use Nette\ComponentModel\IComponent;

final class HomePresenter extends Nette\Application\UI\Presenter
{
    public function __construct(
        private readonly RegistrationFormFactory $registrationFormFactory,
    ) {
    }

    protected function createComponentRegistrace(): IComponent
    {
        // Vytvoreni komponenty s formularem
        return $this->registrationFormFactory->create();
    }
}
